import { genkit } from 'genkit';

export const ai = genkit({
  plugins: [],
});
